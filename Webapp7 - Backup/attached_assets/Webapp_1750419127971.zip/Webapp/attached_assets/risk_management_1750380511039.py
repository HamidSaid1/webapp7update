"""
Risk management module for position sizing and trade validation
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional

class RiskManager:
    """Risk management system for trading operations"""
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Risk tracking
        self.daily_loss = 0.0
        self.trade_cooldowns = {}
        self.daily_trade_count = 0
        self.last_reset_date = datetime.now().date()
        
    def can_trade(self, symbol: str, active_orders: Dict) -> bool:
        """Check if trading is allowed for the given symbol"""
        try:
            # Reset daily counters if new day
            self._reset_daily_counters()
            
            # Check maximum open trades
            if len(active_orders) >= self.config.max_open_trades:
                self.logger.info(f"Maximum open trades reached: {len(active_orders)}")
                return False
                
            # Check daily loss limit
            if abs(self.daily_loss) >= self.config.max_daily_loss:
                self.logger.warning(f"Daily loss limit reached: ${self.daily_loss:.2f}")
                return False
                
            # Check symbol-specific cooldown
            if self._is_in_cooldown(symbol):
                self.logger.info(f"Symbol {symbol} is in cooldown period")
                return False
                
            # Check if already have position in this symbol
            if symbol in active_orders:
                self.logger.info(f"Already have active position in {symbol}")
                return False
                
            return True
            
        except Exception as e:
            self.logger.error(f"Risk check error for {symbol}: {e}")
            return False
            
    def validate_position_size(self, symbol: str, quantity: int, price: float) -> bool:
        """Validate if position size is within risk limits"""
        try:
            position_value = quantity * price
            
            # Check against equity per trade limit
            if position_value > self.config.equity_per_trade:
                self.logger.warning(f"Position size too large: ${position_value:.2f} > ${self.config.equity_per_trade:.2f}")
                return False
                
            # Check against percentage of account
            # This would need account value from IBKR in a real implementation
            # For now, we'll use a simple check
            
            return True
            
        except Exception as e:
            self.logger.error(f"Position size validation error: {e}")
            return False
            
    def calculate_stop_loss(self, entry_price: float, direction: str = 'LONG') -> float:
        """Calculate stop loss price based on entry price and risk percentage"""
        try:
            if direction.upper() == 'LONG':
                stop_loss = entry_price * (1 - self.config.hard_stop_loss)
            else:  # SHORT
                stop_loss = entry_price * (1 + self.config.hard_stop_loss)
                
            return stop_loss
            
        except Exception as e:
            self.logger.error(f"Stop loss calculation error: {e}")
            return entry_price * 0.97  # Default 3% stop loss
            
    def calculate_position_risk(self, entry_price: float, stop_loss: float, quantity: int) -> Dict:
        """Calculate risk metrics for a position"""
        try:
            risk_per_share = abs(entry_price - stop_loss)
            total_risk = risk_per_share * quantity
            position_value = entry_price * quantity
            risk_percentage = (total_risk / position_value) * 100
            
            return {
                'risk_per_share': risk_per_share,
                'total_risk': total_risk,
                'position_value': position_value,
                'risk_percentage': risk_percentage,
                'reward_risk_ratio': self._calculate_reward_risk_ratio(entry_price, stop_loss)
            }
            
        except Exception as e:
            self.logger.error(f"Position risk calculation error: {e}")
            return {'risk_per_share': 0, 'total_risk': 0, 'position_value': 0, 
                   'risk_percentage': 0, 'reward_risk_ratio': 0}
            
    def _calculate_reward_risk_ratio(self, entry_price: float, stop_loss: float) -> float:
        """Calculate potential reward to risk ratio (assuming 2:1 target)"""
        try:
            risk = abs(entry_price - stop_loss)
            reward = risk * 2  # 2:1 reward-to-risk ratio
            return reward / risk if risk > 0 else 0
            
        except Exception as e:
            self.logger.error(f"Reward-risk ratio calculation error: {e}")
            return 2.0  # Default 2:1 ratio
            
    def add_trade_cooldown(self, symbol: str):
        """Add symbol to cooldown period after trade execution"""
        try:
            cooldown_end = datetime.now() + timedelta(minutes=self.config.cooldown_minutes)
            self.trade_cooldowns[symbol] = cooldown_end
            self.logger.info(f"Added {symbol} to cooldown until {cooldown_end}")
            
        except Exception as e:
            self.logger.error(f"Cooldown addition error: {e}")
            
    def _is_in_cooldown(self, symbol: str) -> bool:
        """Check if symbol is in cooldown period"""
        try:
            if symbol not in self.trade_cooldowns:
                return False
                
            if datetime.now() > self.trade_cooldowns[symbol]:
                # Cooldown expired, remove it
                del self.trade_cooldowns[symbol]
                return False
                
            return True
            
        except Exception as e:
            self.logger.error(f"Cooldown check error: {e}")
            return False
            
    def update_daily_pnl(self, pnl: float):
        """Update daily P&L tracking"""
        try:
            self._reset_daily_counters()
            self.daily_loss += pnl
            
            if pnl < 0:
                self.logger.warning(f"Trade loss recorded: ${pnl:.2f}, Daily total: ${self.daily_loss:.2f}")
            else:
                self.logger.info(f"Trade profit recorded: ${pnl:.2f}, Daily total: ${self.daily_loss:.2f}")
                
        except Exception as e:
            self.logger.error(f"Daily P&L update error: {e}")
            
    def _reset_daily_counters(self):
        """Reset daily counters if it's a new day"""
        try:
            current_date = datetime.now().date()
            if current_date > self.last_reset_date:
                self.daily_loss = 0.0
                self.daily_trade_count = 0
                self.last_reset_date = current_date
                self.logger.info("Daily risk counters reset for new trading day")
                
        except Exception as e:
            self.logger.error(f"Daily counter reset error: {e}")
            
    def get_risk_summary(self) -> Dict:
        """Get current risk management summary"""
        try:
            self._reset_daily_counters()
            
            return {
                'daily_pnl': self.daily_loss,
                'daily_loss_limit': self.config.max_daily_loss,
                'loss_limit_remaining': self.config.max_daily_loss - abs(self.daily_loss),
                'daily_trade_count': self.daily_trade_count,
                'symbols_in_cooldown': list(self.trade_cooldowns.keys()),
                'max_open_trades': self.config.max_open_trades,
                'hard_stop_loss_percent': self.config.hard_stop_loss * 100
            }
            
        except Exception as e:
            self.logger.error(f"Risk summary error: {e}")
            return {}
            
    def is_market_hours(self) -> bool:
        """Check if current time is within market hours (basic implementation)"""
        try:
            now = datetime.now()
            # Basic check for US market hours (9:30 AM - 4:00 PM ET)
            # In a real implementation, you'd want to use proper timezone handling
            # and account for holidays
            
            if now.weekday() >= 5:  # Weekend
                return False
                
            market_open = now.replace(hour=9, minute=30, second=0, microsecond=0)
            market_close = now.replace(hour=16, minute=0, second=0, microsecond=0)
            
            return market_open <= now <= market_close
            
        except Exception as e:
            self.logger.error(f"Market hours check error: {e}")
            return True  # Default to allowing trades
            
    def check_volatility_risk(self, symbol: str, volatility: float) -> bool:
        """Check if volatility is within acceptable limits"""
        try:
            # Define maximum acceptable volatility (e.g., 100% annualized)
            max_volatility = 1.0
            
            if volatility > max_volatility:
                self.logger.warning(f"High volatility detected for {symbol}: {volatility:.2%}")
                return False
                
            return True
            
        except Exception as e:
            self.logger.error(f"Volatility risk check error: {e}")
            return True
            
    def validate_trade_parameters(self, symbol: str, quantity: int, price: float, 
                                 stop_loss: float, direction: str = 'LONG') -> Dict:
        """Comprehensive trade parameter validation"""
        try:
            validation_results = {
                'is_valid': True,
                'errors': [],
                'warnings': []
            }
            
            # Basic parameter checks
            if quantity <= 0:
                validation_results['errors'].append("Quantity must be positive")
                validation_results['is_valid'] = False
                
            if price <= 0:
                validation_results['errors'].append("Price must be positive")
                validation_results['is_valid'] = False
                
            if stop_loss <= 0:
                validation_results['errors'].append("Stop loss must be positive")
                validation_results['is_valid'] = False
                
            # Risk checks
            position_value = quantity * price
            if position_value > self.config.equity_per_trade:
                validation_results['errors'].append(f"Position size exceeds limit: ${position_value:.2f}")
                validation_results['is_valid'] = False
                
            # Stop loss validation
            if direction.upper() == 'LONG' and stop_loss >= price:
                validation_results['errors'].append("Stop loss must be below entry price for long positions")
                validation_results['is_valid'] = False
                
            if direction.upper() == 'SHORT' and stop_loss <= price:
                validation_results['errors'].append("Stop loss must be above entry price for short positions")
                validation_results['is_valid'] = False
                
            # Risk percentage check
            risk_per_share = abs(price - stop_loss)
            risk_percentage = (risk_per_share / price) * 100
            
            if risk_percentage > (self.config.hard_stop_loss * 100 * 1.5):  # 1.5x buffer
                validation_results['warnings'].append(f"High risk per share: {risk_percentage:.1f}%")
                
            return validation_results
            
        except Exception as e:
            self.logger.error(f"Trade validation error: {e}")
            return {'is_valid': False, 'errors': [str(e)], 'warnings': []}
