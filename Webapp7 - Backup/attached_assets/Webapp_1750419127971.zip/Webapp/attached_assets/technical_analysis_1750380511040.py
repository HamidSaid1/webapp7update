"""
Technical analysis module for trading signals
"""

import pandas as pd
import numpy as np
from typing import Dict, Optional
import logging
from sklearn.linear_model import LinearRegression

class TechnicalAnalyzer:
    """Technical analysis calculator and signal generator"""
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
    def analyze(self, df: pd.DataFrame, symbol: str) -> Optional[Dict]:
        """Perform complete technical analysis on price data"""
        try:
            if df is None or len(df) < self.config.rsi_period:
                return None
                
            # Ensure we have required columns
            if not all(col in df.columns for col in ['close', 'high', 'low', 'volume']):
                return None
                
            # Calculate all indicators
            analysis = {
                'symbol': symbol,
                'timestamp': pd.Timestamp.now(),
                'current_price': df['close'].iloc[-1],
                'rsi': self.calculate_rsi(df),
                'bollinger': self.calculate_bollinger_bands(df),
                'stochastic': self.calculate_stochastic(df),
                'price_change': self.calculate_price_change(df),
                'volume_analysis': self.calculate_volume_analysis(df),
                'trend': self.calculate_trend(df)
            }
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Technical analysis error for {symbol}: {e}")
            return None
            
    def calculate_rsi(self, df: pd.DataFrame) -> Dict:
        """Calculate Relative Strength Index"""
        try:
            delta = df['close'].diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=self.config.rsi_period).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=self.config.rsi_period).mean()
            
            rs = gain / loss
            rsi = 100 - (100 / (1 + rs))
            
            current_rsi = rsi.iloc[-1]
            prev_rsi = rsi.iloc[-2] if len(rsi) > 1 else current_rsi
            
            return {
                'value': current_rsi,
                'previous': prev_rsi,
                'change': current_rsi - prev_rsi,
                'overbought': current_rsi > 70,
                'oversold': current_rsi < 30,
                'trend': 'up' if current_rsi > prev_rsi else 'down'
            }
            
        except Exception as e:
            self.logger.error(f"RSI calculation error: {e}")
            return {'value': 50, 'previous': 50, 'change': 0, 'overbought': False, 'oversold': False, 'trend': 'neutral'}
            
    def calculate_bollinger_bands(self, df: pd.DataFrame) -> Dict:
        """Calculate Bollinger Bands"""
        try:
            sma = df['close'].rolling(window=self.config.bb_period).mean()
            std = df['close'].rolling(window=self.config.bb_period).std()
            
            upper_band = sma + (std * self.config.bb_std_dev)
            lower_band = sma - (std * self.config.bb_std_dev)
            
            current_price = df['close'].iloc[-1]
            current_upper = upper_band.iloc[-1]
            current_lower = lower_band.iloc[-1]
            current_sma = sma.iloc[-1]
            
            # Calculate position within bands (0-100%)
            bb_position = ((current_price - current_lower) / (current_upper - current_lower)) * 100
            
            return {
                'upper_band': current_upper,
                'lower_band': current_lower,
                'middle_band': current_sma,
                'position_percent': bb_position,
                'squeeze': (current_upper - current_lower) / current_sma < 0.1,  # Bands are tight
                'breakout_up': current_price > current_upper,
                'breakout_down': current_price < current_lower
            }
            
        except Exception as e:
            self.logger.error(f"Bollinger bands calculation error: {e}")
            return {'upper_band': 0, 'lower_band': 0, 'middle_band': 0, 'position_percent': 50, 
                   'squeeze': False, 'breakout_up': False, 'breakout_down': False}
            
    def calculate_stochastic(self, df: pd.DataFrame) -> Dict:
        """Calculate Stochastic Oscillator"""
        try:
            lowest_low = df['low'].rolling(window=self.config.stoch_k_period).min()
            highest_high = df['high'].rolling(window=self.config.stoch_k_period).max()
            
            k_percent = ((df['close'] - lowest_low) / (highest_high - lowest_low)) * 100
            d_percent = k_percent.rolling(window=self.config.stoch_d_period).mean()
            
            current_k = k_percent.iloc[-1]
            current_d = d_percent.iloc[-1]
            
            return {
                'k_percent': current_k,
                'd_percent': current_d,
                'overbought': current_k > 80 and current_d > 80,
                'oversold': current_k < 20 and current_d < 20,
                'bullish_crossover': current_k > current_d and k_percent.iloc[-2] <= d_percent.iloc[-2],
                'bearish_crossover': current_k < current_d and k_percent.iloc[-2] >= d_percent.iloc[-2]
            }
            
        except Exception as e:
            self.logger.error(f"Stochastic calculation error: {e}")
            return {'k_percent': 50, 'd_percent': 50, 'overbought': False, 'oversold': False,
                   'bullish_crossover': False, 'bearish_crossover': False}
            
    def calculate_price_change(self, df: pd.DataFrame) -> Dict:
        """Calculate price change metrics"""
        try:
            current_price = df['close'].iloc[-1]
            previous_price = df['close'].iloc[-2] if len(df) > 1 else current_price
            
            change = current_price - previous_price
            change_percent = (change / previous_price) * 100 if previous_price != 0 else 0
            
            # Calculate volatility (standard deviation of returns)
            returns = df['close'].pct_change().dropna()
            volatility = returns.std() * np.sqrt(252)  # Annualized volatility
            
            return {
                'absolute_change': change,
                'percent_change': change_percent,
                'current_price': current_price,
                'previous_price': previous_price,
                'volatility': volatility,
                'is_gaining': change > 0
            }
            
        except Exception as e:
            self.logger.error(f"Price change calculation error: {e}")
            return {'absolute_change': 0, 'percent_change': 0, 'current_price': 0, 
                   'previous_price': 0, 'volatility': 0, 'is_gaining': False}
            
    def calculate_volume_analysis(self, df: pd.DataFrame) -> Dict:
        """Calculate volume-based indicators"""
        try:
            current_volume = df['volume'].iloc[-1]
            avg_volume = df['volume'].rolling(window=20).mean().iloc[-1]
            
            volume_ratio = current_volume / avg_volume if avg_volume != 0 else 1
            
            # On-Balance Volume
            obv = 0
            for i in range(1, len(df)):
                if df['close'].iloc[i] > df['close'].iloc[i-1]:
                    obv += df['volume'].iloc[i]
                elif df['close'].iloc[i] < df['close'].iloc[i-1]:
                    obv -= df['volume'].iloc[i]
                    
            return {
                'current_volume': current_volume,
                'average_volume': avg_volume,
                'volume_ratio': volume_ratio,
                'high_volume': volume_ratio > 2.0,
                'obv': obv
            }
            
        except Exception as e:
            self.logger.error(f"Volume analysis error: {e}")
            return {'current_volume': 0, 'average_volume': 0, 'volume_ratio': 1,
                   'high_volume': False, 'obv': 0}
            
    def calculate_trend(self, df: pd.DataFrame) -> Dict:
        """Calculate trend analysis using linear regression"""
        try:
            prices = df['close'].values[-20:]  # Last 20 periods
            x = np.arange(len(prices)).reshape(-1, 1)
            y = prices.reshape(-1, 1)
            
            model = LinearRegression().fit(x, y)
            slope = model.coef_[0][0]
            
            # Moving averages for trend confirmation
            sma_short = df['close'].rolling(window=5).mean().iloc[-1]
            sma_long = df['close'].rolling(window=20).mean().iloc[-1]
            
            return {
                'slope': slope,
                'direction': 'up' if slope > 0 else 'down',
                'strength': abs(slope),
                'sma_short': sma_short,
                'sma_long': sma_long,
                'ma_bullish': sma_short > sma_long,
                'trend_strong': abs(slope) > 0.1
            }
            
        except Exception as e:
            self.logger.error(f"Trend calculation error: {e}")
            return {'slope': 0, 'direction': 'neutral', 'strength': 0,
                   'sma_short': 0, 'sma_long': 0, 'ma_bullish': False, 'trend_strong': False}
            
    def get_trading_signals(self, analysis: Dict) -> Dict:
        """Generate trading signals based on technical analysis"""
        try:
            buy_signals = []
            sell_signals = []
            
            # RSI signals
            if analysis['rsi']['oversold'] and analysis['rsi']['trend'] == 'up':
                buy_signals.append('rsi_oversold_recovery')
            if analysis['rsi']['overbought'] and analysis['rsi']['trend'] == 'down':
                sell_signals.append('rsi_overbought_decline')
                
            # Bollinger Band signals
            if analysis['bollinger']['breakout_down'] and analysis['rsi']['oversold']:
                buy_signals.append('bb_oversold_bounce')
            if analysis['bollinger']['breakout_up'] and analysis['rsi']['overbought']:
                sell_signals.append('bb_overbought_reversal')
                
            # Stochastic signals
            if analysis['stochastic']['bullish_crossover'] and analysis['stochastic']['oversold']:
                buy_signals.append('stoch_bullish_crossover')
            if analysis['stochastic']['bearish_crossover'] and analysis['stochastic']['overbought']:
                sell_signals.append('stoch_bearish_crossover')
                
            # Trend signals
            if (analysis['trend']['ma_bullish'] and 
                analysis['trend']['direction'] == 'up' and 
                analysis['volume_analysis']['high_volume']):
                buy_signals.append('trend_momentum_buy')
                
            if (not analysis['trend']['ma_bullish'] and 
                analysis['trend']['direction'] == 'down' and 
                analysis['volume_analysis']['high_volume']):
                sell_signals.append('trend_momentum_sell')
                
            # Price action signals
            if (analysis['price_change']['percent_change'] > 2 and
                analysis['volume_analysis']['volume_ratio'] > 1.5):
                buy_signals.append('price_volume_breakout')
                
            return {
                'buy_signal': len(buy_signals) >= 2,  # Require at least 2 buy signals
                'sell_signal': len(sell_signals) >= 2,  # Require at least 2 sell signals
                'buy_reasons': buy_signals,
                'sell_reasons': sell_signals,
                'signal_strength': max(len(buy_signals), len(sell_signals))
            }
            
        except Exception as e:
            self.logger.error(f"Signal generation error: {e}")
            return {'buy_signal': False, 'sell_signal': False, 'buy_reasons': [], 
                   'sell_reasons': [], 'signal_strength': 0}
            
    def calculate_support_resistance(self, df: pd.DataFrame) -> Dict:
        """Calculate support and resistance levels"""
        try:
            # Find local maxima and minima
            highs = df['high'].rolling(window=5, center=True).max()
            lows = df['low'].rolling(window=5, center=True).min()
            
            resistance_levels = []
            support_levels = []
            
            for i in range(2, len(df) - 2):
                if df['high'].iloc[i] == highs.iloc[i]:
                    resistance_levels.append(df['high'].iloc[i])
                if df['low'].iloc[i] == lows.iloc[i]:
                    support_levels.append(df['low'].iloc[i])
                    
            # Get most recent levels
            current_price = df['close'].iloc[-1]
            
            nearby_resistance = [r for r in resistance_levels if r > current_price]
            nearby_support = [s for s in support_levels if s < current_price]
            
            return {
                'nearest_resistance': min(nearby_resistance) if nearby_resistance else None,
                'nearest_support': max(nearby_support) if nearby_support else None,
                'all_resistance': resistance_levels,
                'all_support': support_levels,
                'at_resistance': any(abs(current_price - r) / current_price < 0.01 for r in nearby_resistance),
                'at_support': any(abs(current_price - s) / current_price < 0.01 for s in nearby_support)
            }
            
        except Exception as e:
            self.logger.error(f"Support/Resistance calculation error: {e}")
            return {'nearest_resistance': None, 'nearest_support': None,
                   'all_resistance': [], 'all_support': [], 'at_resistance': False, 'at_support': False}
