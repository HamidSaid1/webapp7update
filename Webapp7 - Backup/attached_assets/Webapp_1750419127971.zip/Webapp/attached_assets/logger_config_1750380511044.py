"""
Logging configuration for the trading application
"""

import logging
import logging.handlers
import os
from datetime import datetime

def setup_logging(log_level=logging.INFO, log_to_file=True, log_to_console=True):
    """
    Setup comprehensive logging configuration
    
    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_to_file: Whether to log to file
        log_to_console: Whether to log to console
    """
    
    # Create logs directory if it doesn't exist
    if log_to_file:
        os.makedirs('logs', exist_ok=True)
    
    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)
    
    # Clear any existing handlers
    root_logger.handlers.clear()
    
    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(name)-20s | %(funcName)-15s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Console handler
    if log_to_console:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(log_level)
        console_handler.setFormatter(formatter)
        root_logger.addHandler(console_handler)
    
    # File handlers
    if log_to_file:
        # Main log file with rotation
        log_filename = f"logs/trading_app_{datetime.now().strftime('%Y%m%d')}.log"
        file_handler = logging.handlers.RotatingFileHandler(
            log_filename,
            maxBytes=10*1024*1024,  # 10MB
            backupCount=5
        )
        file_handler.setLevel(log_level)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)
        
        # Error log file (errors and above only)
        error_log_filename = f"logs/trading_errors_{datetime.now().strftime('%Y%m%d')}.log"
        error_handler = logging.handlers.RotatingFileHandler(
            error_log_filename,
            maxBytes=5*1024*1024,  # 5MB
            backupCount=3
        )
        error_handler.setLevel(logging.ERROR)
        error_handler.setFormatter(formatter)
        root_logger.addHandler(error_handler)
        
        # Trading activity log (separate file for trade-specific events)
        trade_log_filename = f"logs/trading_activity_{datetime.now().strftime('%Y%m%d')}.log"
        trade_handler = logging.handlers.RotatingFileHandler(
            trade_log_filename,
            maxBytes=20*1024*1024,  # 20MB
            backupCount=10
        )
        trade_handler.setLevel(logging.INFO)
        
        # Custom formatter for trade logs
        trade_formatter = logging.Formatter(
            '%(asctime)s | %(levelname)-8s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        trade_handler.setFormatter(trade_formatter)
        
        # Create a separate logger for trading activities
        trade_logger = logging.getLogger('trading_activity')
        trade_logger.addHandler(trade_handler)
        trade_logger.setLevel(logging.INFO)
        trade_logger.propagate = False  # Don't propagate to root logger
    
    # Configure third-party library logging levels
    logging.getLogger('ib_insync').setLevel(logging.WARNING)
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('PIL').setLevel(logging.WARNING)
    logging.getLogger('matplotlib').setLevel(logging.WARNING)
    
    # Log initial setup message
    root_logger.info("="*80)
    root_logger.info("AutoTrade Plus - Trading Application Started")
    root_logger.info(f"Log Level: {logging.getLevelName(log_level)}")
    root_logger.info(f"Console Logging: {'Enabled' if log_to_console else 'Disabled'}")
    root_logger.info(f"File Logging: {'Enabled' if log_to_file else 'Disabled'}")
    root_logger.info("="*80)

def get_trade_logger():
    """Get the dedicated trading activity logger"""
    return logging.getLogger('trading_activity')

def log_trade_event(event_type: str, symbol: str, details: dict):
    """
    Log trading events with structured format
    
    Args:
        event_type: Type of event (BUY, SELL, ERROR, etc.)
        symbol: Stock symbol
        details: Dictionary of additional details
    """
    trade_logger = get_trade_logger()
    
    # Format the log message
    message_parts = [f"[{event_type}]", f"Symbol: {symbol}"]
    
    for key, value in details.items():
        if isinstance(value, float):
            if 'price' in key.lower() or 'pnl' in key.lower():
                message_parts.append(f"{key}: ${value:.2f}")
            elif 'percent' in key.lower() or 'rate' in key.lower():
                message_parts.append(f"{key}: {value:.2f}%")
            else:
                message_parts.append(f"{key}: {value:.4f}")
        else:
            message_parts.append(f"{key}: {value}")
    
    log_message = " | ".join(message_parts)
    trade_logger.info(log_message)

def log_connection_event(event_type: str, details: str):
    """Log IBKR connection events"""
    logger = logging.getLogger('connection')
    logger.info(f"[{event_type}] {details}")

def log_analysis_event(symbol: str, analysis_results: dict):
    """Log technical analysis results"""
    logger = logging.getLogger('analysis')
    
    # Extract key metrics for logging
    rsi = analysis_results.get('rsi', {}).get('value', 0)
    bb_pos = analysis_results.get('bollinger', {}).get('position_percent', 0)
    price_change = analysis_results.get('price_change', {}).get('percent_change', 0)
    
    logger.debug(f"Analysis for {symbol}: RSI={rsi:.1f}, BB%={bb_pos:.1f}, Price Δ={price_change:+.2f}%")

def log_risk_event(event_type: str, symbol: str, risk_details: dict):
    """Log risk management events"""
    logger = logging.getLogger('risk_management')
    
    message_parts = [f"[{event_type}]", f"Symbol: {symbol}"]
    
    for key, value in risk_details.items():
        if isinstance(value, float) and 'amount' in key.lower():
            message_parts.append(f"{key}: ${value:.2f}")
        else:
            message_parts.append(f"{key}: {value}")
    
    log_message = " | ".join(message_parts)
    logger.warning(log_message)

def log_performance_metrics(metrics: dict):
    """Log performance metrics periodically"""
    logger = logging.getLogger('performance')
    
    message_parts = ["PERFORMANCE METRICS"]
    
    for key, value in metrics.items():
        if isinstance(value, float):
            if 'pnl' in key.lower() or 'balance' in key.lower():
                message_parts.append(f"{key}: ${value:.2f}")
            elif 'rate' in key.lower() or 'percent' in key.lower():
                message_parts.append(f"{key}: {value:.2f}%")
            else:
                message_parts.append(f"{key}: {value:.4f}")
        else:
            message_parts.append(f"{key}: {value}")
    
    log_message = " | ".join(message_parts)
    logger.info(log_message)

# Custom exception handler for uncaught exceptions
import sys
import traceback

def handle_exception(exc_type, exc_value, exc_traceback):
    """Handle uncaught exceptions"""
    if issubclass(exc_type, KeyboardInterrupt):
        # Allow Ctrl+C to work normally
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return
    
    logger = logging.getLogger(__name__)
    logger.critical("Uncaught exception:", exc_info=(exc_type, exc_value, exc_traceback))

# Set the exception handler
sys.excepthook = handle_exception

def setup_debug_logging():
    """Setup debug-level logging for development"""
    setup_logging(log_level=logging.DEBUG, log_to_file=True, log_to_console=True)
    
    # Additional debug loggers
    debug_loggers = [
        'trading_engine',
        'technical_analysis', 
        'risk_management',
        'gui_components'
    ]
    
    for logger_name in debug_loggers:
        logger = logging.getLogger(logger_name)
        logger.setLevel(logging.DEBUG)

def cleanup_old_logs(days_to_keep: int = 30):
    """Clean up log files older than specified days"""
    try:
        import glob
        from pathlib import Path
        
        if not os.path.exists('logs'):
            return
            
        cutoff_date = datetime.now() - timedelta(days=days_to_keep)
        
        log_files = glob.glob('logs/*.log*')
        
        for log_file in log_files:
            file_path = Path(log_file)
            if file_path.stat().st_mtime < cutoff_date.timestamp():
                os.remove(log_file)
                logging.getLogger(__name__).info(f"Removed old log file: {log_file}")
                
    except Exception as e:
        logging.getLogger(__name__).error(f"Log cleanup error: {e}")
