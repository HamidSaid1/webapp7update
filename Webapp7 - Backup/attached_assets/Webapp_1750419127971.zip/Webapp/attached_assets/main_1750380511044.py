"""
Interactive Brokers Trading Application
Main entry point for the trading application with GUI and real-time market analysis.
"""

import tkinter as tk
import asyncio
import threading
import logging
from config import TradingConfig
from trading_engine import TradingEngine
from gui_components import TradingGUI
from logger_config import setup_logging
import nest_asyncio

# Enable nested asyncio for compatibility with tkinter
nest_asyncio.apply()

class TradingApplication:
    """Main application class that coordinates all components"""
    
    def __init__(self):
        self.setup_logging()
        self.config = TradingConfig()
        self.root = tk.Tk()
        self.trading_engine = TradingEngine(self.config)
        self.gui = TradingGUI(self.root, self.trading_engine, self.config)
        
        # Setup callbacks
        self.trading_engine.set_gui_callback(self.gui.update_market_data)
        self.trading_engine.set_trade_callback(self.gui.update_trades_display)
        
        self.logger = logging.getLogger(__name__)
        
    def setup_logging(self):
        """Initialize logging configuration"""
        setup_logging()
        
    def start_async_loop(self):
        """Start the asyncio event loop in a separate thread"""
        def run_loop():
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                self.trading_engine.set_event_loop(loop)
                loop.run_forever()
            except Exception as e:
                self.logger.error(f"Async loop error: {e}")
                
        thread = threading.Thread(target=run_loop, daemon=True)
        thread.start()
        self.logger.info("Async event loop started")
        
    def run(self):
        """Start the trading application"""
        try:
            self.logger.info("Starting Trading Application")
            
            # Start async loop for IBKR operations
            self.start_async_loop()
            
            # Configure root window
            self.root.title("AutoTrade Plus - Interactive Brokers Trading")
            self.root.geometry("1400x900")
            self.root.configure(bg="#f8f9fa")
            
            # Handle window close
            self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
            
            # Start GUI
            self.root.mainloop()
            
        except Exception as e:
            self.logger.error(f"Application startup error: {e}")
            raise
    
    def on_closing(self):
        """Handle application shutdown"""
        try:
            self.logger.info("Shutting down application")
            self.trading_engine.disconnect()
            self.root.destroy()
        except Exception as e:
            self.logger.error(f"Shutdown error: {e}")

if __name__ == "__main__":
    app = TradingApplication()
    app.run()
