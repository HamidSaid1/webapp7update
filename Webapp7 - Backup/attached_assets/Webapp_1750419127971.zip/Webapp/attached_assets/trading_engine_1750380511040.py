"""
Core trading engine with IBKR integration and strategy execution
"""

import asyncio
import logging
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable
import pandas as pd
import numpy as np
from ib_insync import IB, Stock, MarketOrder, LimitOrder, util
from technical_analysis import TechnicalAnalyzer
from risk_management import RiskManager
from utils import calculate_position_size, format_currency

class TradingEngine:
    """Main trading engine that handles IBKR connection and trade execution"""
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # IBKR connection
        self.ib = IB()
        self.is_connected = False
        self.next_order_id = 1
        
        # Data and analysis
        self.market_data = {}
        self.active_orders = {}
        self.trade_history = []
        self.is_streaming = False
        
        # Components
        self.technical_analyzer = TechnicalAnalyzer(config)
        self.risk_manager = RiskManager(config)
        
        # Callbacks
        self.gui_callback = None
        self.trade_callback = None
        
        # Event loop
        self.event_loop = None
        
        # Performance tracking
        self.daily_pnl = 0.0
        self.total_trades = 0
        self.winning_trades = 0
        
        # Setup IBKR event handlers
        self.setup_event_handlers()
        
    def setup_event_handlers(self):
        """Setup IBKR event handlers"""
        self.ib.orderStatusEvent += self.on_order_status
        self.ib.execDetailsEvent += self.on_execution
        self.ib.errorEvent += self.on_error
        self.ib.disconnectedEvent += self.on_disconnect
        
    def set_event_loop(self, loop):
        """Set the asyncio event loop"""
        self.event_loop = loop
        
    def set_gui_callback(self, callback: Callable):
        """Set callback for GUI updates"""
        self.gui_callback = callback
        
    def set_trade_callback(self, callback: Callable):
        """Set callback for trade updates"""
        self.trade_callback = callback
        
    async def connect_ibkr(self) -> bool:
        """Connect to IBKR API"""
        try:
            self.logger.info(f"Connecting to IBKR at {self.config.ibkr_host}:{self.config.ibkr_port}")
            
            await self.ib.connectAsync(
                host=self.config.ibkr_host,
                port=self.config.ibkr_port,
                clientId=self.config.client_id
            )
            
            self.is_connected = True
            self.logger.info("Successfully connected to IBKR")
            return True
            
        except Exception as e:
            self.logger.error(f"IBKR connection failed: {e}")
            self.is_connected = False
            return False
            
    def disconnect(self):
        """Disconnect from IBKR"""
        try:
            if self.is_connected:
                self.stop_streaming()
                self.ib.disconnect()
                self.is_connected = False
                self.logger.info("Disconnected from IBKR")
        except Exception as e:
            self.logger.error(f"Disconnect error: {e}")
            
    async def start_streaming(self, tickers: str) -> bool:
        """Start real-time market data streaming"""
        if not self.is_connected:
            success = await self.connect_ibkr()
            if not success:
                return False
                
        try:
            self.is_streaming = True
            ticker_list = [t.strip().upper() for t in tickers.split(',')]
            
            self.logger.info(f"Starting streaming for: {ticker_list}")
            
            # Subscribe to market data
            contracts = []
            for symbol in ticker_list:
                contract = Stock(symbol, self.config.default_exchange, 'USD')
                contracts.append(contract)
                
                # Initialize market data structure
                self.market_data[symbol] = {
                    'contract': contract,
                    'last': 0.0,
                    'bid': 0.0,
                    'ask': 0.0,
                    'volume': 0,
                    'timestamp': datetime.now(),
                    'history': []
                }
            
            # Request market data
            for contract in contracts:
                self.ib.reqMktData(contract)
                
            # Start analysis loop
            asyncio.create_task(self.analysis_loop())
            return True
            
        except Exception as e:
            self.logger.error(f"Streaming start error: {e}")
            self.is_streaming = False
            return False
            
    def stop_streaming(self):
        """Stop market data streaming"""
        try:
            self.is_streaming = False
            
            # Cancel market data subscriptions
            for symbol, data in self.market_data.items():
                if 'contract' in data:
                    self.ib.cancelMktData(data['contract'])
                    
            self.logger.info("Market data streaming stopped")
            
        except Exception as e:
            self.logger.error(f"Stop streaming error: {e}")
            
    async def analysis_loop(self):
        """Main analysis loop for real-time processing"""
        while self.is_streaming:
            try:
                await self.process_market_data()
                await asyncio.sleep(self.config.analysis_interval)
                
            except Exception as e:
                self.logger.error(f"Analysis loop error: {e}")
                await asyncio.sleep(1)
                
    async def process_market_data(self):
        """Process current market data and execute trading logic"""
        for symbol, data in self.market_data.items():
            try:
                # Get historical data
                bars = await self.get_historical_data(data['contract'])
                if bars is None or len(bars) < self.config.rsi_period:
                    continue
                    
                # Update current price
                ticker = self.ib.ticker(data['contract'])
                if ticker and ticker.last:
                    data['last'] = ticker.last
                    data['bid'] = ticker.bid or 0.0
                    data['ask'] = ticker.ask or 0.0
                    data['timestamp'] = datetime.now()
                    
                # Perform technical analysis
                analysis = self.technical_analyzer.analyze(bars, symbol)
                if analysis:
                    data.update(analysis)
                    
                    # Check for trading opportunities
                    await self.evaluate_trade_opportunity(symbol, data, analysis)
                    
                # Update GUI if callback is set
                if self.gui_callback:
                    self.gui_callback(self.market_data)
                    
            except Exception as e:
                self.logger.error(f"Market data processing error for {symbol}: {e}")
                
    async def get_historical_data(self, contract, duration="1 D", bar_size="5 mins"):
        """Get historical bar data from IBKR"""
        try:
            bars = self.ib.reqHistoricalData(
                contract,
                endDateTime='',
                durationStr=duration,
                barSizeSetting=bar_size,
                whatToShow='TRADES',
                useRTH=True
            )
            return util.df(bars) if bars else None
            
        except Exception as e:
            self.logger.error(f"Historical data error: {e}")
            return None
            
    async def evaluate_trade_opportunity(self, symbol: str, market_data: dict, analysis: dict):
        """Evaluate if current conditions warrant a trade"""
        try:
            # Check if we can trade this symbol
            if not self.risk_manager.can_trade(symbol, self.active_orders):
                return
                
            # Get trading signals
            signals = self.technical_analyzer.get_trading_signals(analysis)
            
            if signals['buy_signal']:
                await self.execute_buy_order(symbol, market_data, analysis)
            elif signals['sell_signal'] and symbol in self.active_orders:
                await self.execute_sell_order(symbol, market_data, analysis)
                
        except Exception as e:
            self.logger.error(f"Trade evaluation error for {symbol}: {e}")
            
    async def execute_buy_order(self, symbol: str, market_data: dict, analysis: dict):
        """Execute a buy order"""
        try:
            current_price = market_data['last']
            if current_price <= 0:
                return
                
            # Calculate position size
            position_size = calculate_position_size(
                self.config.equity_per_trade,
                current_price,
                self.config.hard_stop_loss
            )
            
            if position_size <= 0:
                return
                
            # Create market order
            contract = market_data['contract']
            order = MarketOrder('BUY', position_size)
            
            # Place order
            trade = self.ib.placeOrder(contract, order)
            
            # Track order
            self.active_orders[symbol] = {
                'trade': trade,
                'quantity': position_size,
                'entry_price': current_price,
                'entry_time': datetime.now(),
                'stop_loss': current_price * (1 - self.config.hard_stop_loss),
                'analysis': analysis.copy(),
                'status': 'PENDING'
            }
            
            self.logger.info(f"Buy order placed for {symbol}: {position_size} shares at ${current_price:.2f}")
            
        except Exception as e:
            self.logger.error(f"Buy order execution error for {symbol}: {e}")
            
    async def execute_sell_order(self, symbol: str, market_data: dict, analysis: dict):
        """Execute a sell order"""
        try:
            if symbol not in self.active_orders:
                return
                
            position = self.active_orders[symbol]
            current_price = market_data['last']
            
            # Check exit conditions
            should_exit = self.should_exit_position(symbol, current_price, position, analysis)
            
            if should_exit:
                # Create market order to close position
                contract = market_data['contract']
                order = MarketOrder('SELL', position['quantity'])
                
                # Place order
                trade = self.ib.placeOrder(contract, order)
                
                # Update position
                position['exit_trade'] = trade
                position['exit_price'] = current_price
                position['exit_time'] = datetime.now()
                position['status'] = 'CLOSING'
                
                # Calculate P&L
                pnl = (current_price - position['entry_price']) * position['quantity']
                position['pnl'] = pnl
                
                self.logger.info(f"Sell order placed for {symbol}: {position['quantity']} shares at ${current_price:.2f}, P&L: ${pnl:.2f}")
                
        except Exception as e:
            self.logger.error(f"Sell order execution error for {symbol}: {e}")
            
    def should_exit_position(self, symbol: str, current_price: float, position: dict, analysis: dict) -> bool:
        """Determine if position should be exited"""
        # Stop loss check
        if current_price <= position['stop_loss']:
            self.logger.info(f"Stop loss triggered for {symbol}")
            return True
            
        # Take profit check (simple 2:1 risk-reward)
        entry_price = position['entry_price']
        risk = entry_price - position['stop_loss']
        take_profit_price = entry_price + (2 * risk)
        
        if current_price >= take_profit_price:
            self.logger.info(f"Take profit triggered for {symbol}")
            return True
            
        # Technical exit signals
        signals = self.technical_analyzer.get_trading_signals(analysis)
        if signals['sell_signal']:
            self.logger.info(f"Technical sell signal for {symbol}")
            return True
            
        return False
        
    def on_order_status(self, trade):
        """Handle order status updates"""
        try:
            symbol = trade.contract.symbol
            status = trade.orderStatus.status
            
            self.logger.info(f"Order status update - {symbol}: {status}")
            
            if status == 'Filled':
                self.on_order_filled(trade)
            elif status == 'Cancelled':
                self.on_order_cancelled(trade)
                
        except Exception as e:
            self.logger.error(f"Order status error: {e}")
            
    def on_order_filled(self, trade):
        """Handle filled orders"""
        try:
            symbol = trade.contract.symbol
            
            if symbol in self.active_orders:
                position = self.active_orders[symbol]
                
                if trade.order.action == 'BUY':
                    position['status'] = 'OPEN'
                    position['actual_entry_price'] = trade.orderStatus.avgFillPrice
                    self.logger.info(f"Buy order filled for {symbol} at ${trade.orderStatus.avgFillPrice:.2f}")
                    
                elif trade.order.action == 'SELL':
                    position['status'] = 'CLOSED'
                    position['actual_exit_price'] = trade.orderStatus.avgFillPrice
                    
                    # Calculate final P&L
                    entry_price = position.get('actual_entry_price', position['entry_price'])
                    exit_price = trade.orderStatus.avgFillPrice
                    quantity = position['quantity']
                    final_pnl = (exit_price - entry_price) * quantity
                    
                    position['final_pnl'] = final_pnl
                    self.daily_pnl += final_pnl
                    self.total_trades += 1
                    
                    if final_pnl > 0:
                        self.winning_trades += 1
                        
                    self.logger.info(f"Sell order filled for {symbol} at ${exit_price:.2f}, Final P&L: ${final_pnl:.2f}")
                    
                    # Move to trade history
                    self.trade_history.append(position.copy())
                    del self.active_orders[symbol]
                    
            # Update trade display
            if self.trade_callback:
                self.trade_callback(self.active_orders, self.trade_history)
                
        except Exception as e:
            self.logger.error(f"Order filled error: {e}")
            
    def on_order_cancelled(self, trade):
        """Handle cancelled orders"""
        symbol = trade.contract.symbol
        self.logger.info(f"Order cancelled for {symbol}")
        
        if symbol in self.active_orders:
            del self.active_orders[symbol]
            
    def on_execution(self, trade, fill):
        """Handle trade executions"""
        self.logger.info(f"Execution: {trade.contract.symbol} - {fill.execution.shares} @ ${fill.execution.price}")
        
    def on_error(self, reqId, errorCode, errorString, contract):
        """Handle IBKR errors"""
        self.logger.error(f"IBKR Error {errorCode}: {errorString}")
        
    def on_disconnect(self):
        """Handle disconnection"""
        self.logger.warning("IBKR connection lost")
        self.is_connected = False
        self.is_streaming = False
        
    def get_account_summary(self) -> dict:
        """Get account summary information"""
        try:
            if not self.is_connected:
                return {}
                
            summary = self.ib.accountSummary()
            result = {}
            
            for item in summary:
                result[item.tag] = item.value
                
            return result
            
        except Exception as e:
            self.logger.error(f"Account summary error: {e}")
            return {}
            
    def get_positions(self) -> list:
        """Get current positions"""
        try:
            if not self.is_connected:
                return []
                
            return self.ib.positions()
            
        except Exception as e:
            self.logger.error(f"Positions error: {e}")
            return []
            
    def get_performance_stats(self) -> dict:
        """Get performance statistics"""
        win_rate = (self.winning_trades / self.total_trades * 100) if self.total_trades > 0 else 0
        
        return {
            'daily_pnl': self.daily_pnl,
            'total_trades': self.total_trades,
            'winning_trades': self.winning_trades,
            'win_rate': win_rate,
            'active_positions': len(self.active_orders)
        }
