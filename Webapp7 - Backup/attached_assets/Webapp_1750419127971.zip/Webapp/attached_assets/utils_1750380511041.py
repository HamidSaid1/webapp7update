"""
Utility functions for the trading application
"""

import logging
from datetime import datetime, timedelta
from typing import Union, Optional
import pandas as pd
import numpy as np

def calculate_position_size(equity_per_trade: float, price: float, stop_loss_percent: float) -> int:
    """
    Calculate position size based on equity allocation and stop loss
    
    Args:
        equity_per_trade: Dollar amount to risk per trade
        price: Current stock price
        stop_loss_percent: Stop loss as a decimal (e.g., 0.03 for 3%)
    
    Returns:
        Number of shares to buy
    """
    try:
        if price <= 0 or stop_loss_percent <= 0:
            return 0
            
        # Calculate risk per share
        risk_per_share = price * stop_loss_percent
        
        # Calculate maximum shares based on risk tolerance
        max_shares = int(equity_per_trade / risk_per_share)
        
        return max_shares
        
    except Exception as e:
        logging.getLogger(__name__).error(f"Position size calculation error: {e}")
        return 0

def format_currency(amount: float, symbol: str = "$") -> str:
    """Format currency with proper symbol and comma separators"""
    try:
        if amount >= 0:
            return f"{symbol}{amount:,.2f}"
        else:
            return f"-{symbol}{abs(amount):,.2f}"
    except:
        return f"{symbol}0.00"

def format_percentage(value: float, decimals: int = 2) -> str:
    """Format percentage with proper sign and decimals"""
    try:
        if value >= 0:
            return f"+{value:.{decimals}f}%"
        else:
            return f"{value:.{decimals}f}%"
    except:
        return "0.00%"

def calculate_time_difference(start_time: datetime, end_time: Optional[datetime] = None) -> str:
    """Calculate human-readable time difference"""
    try:
        if end_time is None:
            end_time = datetime.now()
            
        diff = end_time - start_time
        
        if diff.days > 0:
            return f"{diff.days}d {diff.seconds // 3600}h"
        elif diff.seconds >= 3600:
            return f"{diff.seconds // 3600}h {(diff.seconds % 3600) // 60}m"
        elif diff.seconds >= 60:
            return f"{diff.seconds // 60}m {diff.seconds % 60}s"
        else:
            return f"{diff.seconds}s"
            
    except Exception as e:
        logging.getLogger(__name__).error(f"Time difference calculation error: {e}")
        return "N/A"

def validate_ticker_symbol(symbol: str) -> bool:
    """Validate ticker symbol format"""
    try:
        if not symbol or not isinstance(symbol, str):
            return False
            
        # Remove whitespace and convert to uppercase
        symbol = symbol.strip().upper()
        
        # Basic validation: letters only, 1-5 characters
        if not symbol.isalpha() or not (1 <= len(symbol) <= 5):
            return False
            
        return True
        
    except Exception as e:
        logging.getLogger(__name__).error(f"Ticker validation error: {e}")
        return False

def parse_ticker_list(tickers_string: str) -> list:
    """Parse comma-separated ticker string into validated list"""
    try:
        if not tickers_string:
            return []
            
        # Split by comma and clean up
        tickers = [t.strip().upper() for t in tickers_string.split(',')]
        
        # Validate each ticker
        valid_tickers = [t for t in tickers if validate_ticker_symbol(t)]
        
        # Remove duplicates while preserving order
        seen = set()
        unique_tickers = []
        for ticker in valid_tickers:
            if ticker not in seen:
                seen.add(ticker)
                unique_tickers.append(ticker)
                
        return unique_tickers
        
    except Exception as e:
        logging.getLogger(__name__).error(f"Ticker list parsing error: {e}")
        return []

def convert_timeframe_to_seconds(timeframe: str) -> int:
    """Convert timeframe string to seconds"""
    try:
        timeframe = timeframe.strip().lower()
        
        mapping = {
            '1 sec': 1,
            '5 sec': 5,
            '10 sec': 10,
            '30 sec': 30,
            '1 min': 60,
            '3 mins': 180,
            '5 mins': 300,
            '10 mins': 600,
            '15 mins': 900,
            '30 mins': 1800,
            '1 hour': 3600,
            '2 hours': 7200,
            '4 hours': 14400,
            '1 day': 86400
        }
        
        return mapping.get(timeframe, 300)  # Default to 5 minutes
        
    except Exception as e:
        logging.getLogger(__name__).error(f"Timeframe conversion error: {e}")
        return 300

def calculate_risk_reward_ratio(entry_price: float, stop_loss: float, take_profit: float) -> float:
    """Calculate risk-to-reward ratio"""
    try:
        if entry_price <= 0 or stop_loss <= 0 or take_profit <= 0:
            return 0
            
        risk = abs(entry_price - stop_loss)
        reward = abs(take_profit - entry_price)
        
        if risk == 0:
            return 0
            
        return reward / risk
        
    except Exception as e:
        logging.getLogger(__name__).error(f"Risk-reward calculation error: {e}")
        return 0

def calculate_compound_return(initial_balance: float, trades: list) -> dict:
    """Calculate compound return from a series of trades"""
    try:
        if not trades or initial_balance <= 0:
            return {'final_balance': initial_balance, 'total_return': 0, 'compound_rate': 0}
            
        current_balance = initial_balance
        
        for trade in trades:
            pnl = trade.get('final_pnl', 0)
            current_balance += pnl
            
        total_return = current_balance - initial_balance
        compound_rate = (current_balance / initial_balance - 1) * 100
        
        return {
            'initial_balance': initial_balance,
            'final_balance': current_balance,
            'total_return': total_return,
            'compound_rate': compound_rate,
            'number_of_trades': len(trades)
        }
        
    except Exception as e:
        logging.getLogger(__name__).error(f"Compound return calculation error: {e}")
        return {'final_balance': initial_balance, 'total_return': 0, 'compound_rate': 0}

def calculate_sharpe_ratio(returns: list, risk_free_rate: float = 0.02) -> float:
    """Calculate Sharpe ratio from returns list"""
    try:
        if not returns or len(returns) < 2:
            return 0
            
        returns_array = np.array(returns)
        
        # Convert to pandas Series for easier calculation
        returns_series = pd.Series(returns_array)
        
        # Calculate excess returns
        excess_returns = returns_series - (risk_free_rate / 252)  # Daily risk-free rate
        
        # Calculate Sharpe ratio
        if excess_returns.std() == 0:
            return 0
            
        sharpe_ratio = excess_returns.mean() / excess_returns.std() * np.sqrt(252)  # Annualized
        
        return sharpe_ratio
        
    except Exception as e:
        logging.getLogger(__name__).error(f"Sharpe ratio calculation error: {e}")
        return 0

def calculate_max_drawdown(equity_curve: list) -> dict:
    """Calculate maximum drawdown from equity curve"""
    try:
        if not equity_curve or len(equity_curve) < 2:
            return {'max_drawdown': 0, 'max_drawdown_percent': 0}
            
        equity_array = np.array(equity_curve)
        
        # Calculate running maximum
        running_max = np.maximum.accumulate(equity_array)
        
        # Calculate drawdown
        drawdown = equity_array - running_max
        
        # Find maximum drawdown
        max_drawdown = np.min(drawdown)
        max_drawdown_percent = (max_drawdown / np.max(running_max)) * 100 if np.max(running_max) > 0 else 0
        
        return {
            'max_drawdown': max_drawdown,
            'max_drawdown_percent': max_drawdown_percent,
            'drawdown_series': drawdown.tolist()
        }
        
    except Exception as e:
        logging.getLogger(__name__).error(f"Max drawdown calculation error: {e}")
        return {'max_drawdown': 0, 'max_drawdown_percent': 0}

def is_market_open(current_time: Optional[datetime] = None) -> bool:
    """Check if market is currently open (basic implementation)"""
    try:
        if current_time is None:
            current_time = datetime.now()
            
        # Check if weekend
        if current_time.weekday() >= 5:  # Saturday = 5, Sunday = 6
            return False
            
        # Market hours: 9:30 AM - 4:00 PM ET (simplified)
        market_open = current_time.replace(hour=9, minute=30, second=0, microsecond=0)
        market_close = current_time.replace(hour=16, minute=0, second=0, microsecond=0)
        
        return market_open <= current_time <= market_close
        
    except Exception as e:
        logging.getLogger(__name__).error(f"Market hours check error: {e}")
        return True  # Default to market open for safety

def generate_trade_id() -> str:
    """Generate unique trade identifier"""
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        return f"TRADE_{timestamp}"
    except Exception as e:
        logging.getLogger(__name__).error(f"Trade ID generation error: {e}")
        return f"TRADE_{int(datetime.now().timestamp())}"

def safe_divide(numerator: float, denominator: float, default: float = 0) -> float:
    """Safely divide two numbers, returning default if denominator is zero"""
    try:
        if denominator == 0:
            return default
        return numerator / denominator
    except:
        return default

def clamp(value: float, min_value: float, max_value: float) -> float:
    """Clamp value between min and max"""
    try:
        return max(min_value, min(value, max_value))
    except:
        return min_value

def exponential_moving_average(data: list, period: int) -> list:
    """Calculate exponential moving average"""
    try:
        if not data or period <= 0:
            return []
            
        # Convert to pandas Series for easier calculation
        series = pd.Series(data)
        ema = series.ewm(span=period).mean()
        
        return ema.tolist()
        
    except Exception as e:
        logging.getLogger(__name__).error(f"EMA calculation error: {e}")
        return data  # Return original data if calculation fails
