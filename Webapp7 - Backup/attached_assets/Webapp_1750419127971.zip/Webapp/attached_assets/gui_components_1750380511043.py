"""
GUI components for the trading application
"""

import tkinter as tk
from tkinter import ttk, messagebox
import logging
from datetime import datetime
from typing import Dict, Any
import threading
import asyncio

class TradingGUI:
    """Main GUI class for the trading application"""
    
    def __init__(self, root, trading_engine, config):
        self.root = root
        self.trading_engine = trading_engine
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # GUI Variables
        self.is_streaming = tk.BooleanVar(value=False)
        self.tickers_var = tk.StringVar(value=config.default_tickers)
        self.exchange_var = tk.StringVar(value=config.default_exchange)
        self.chart_interval_var = tk.StringVar(value=config.chart_interval)
        self.force_trade_var = tk.BooleanVar(value=False)
        
        # Status variables
        self.connection_status = tk.StringVar(value="Disconnected")
        self.streaming_status = tk.StringVar(value="Stopped")
        self.account_balance = tk.StringVar(value="$0.00")
        
        # Setup GUI
        self.setup_main_interface()
        self.setup_menu_bar()
        
        # Start periodic updates
        self.start_periodic_updates()
        
    def setup_main_interface(self):
        """Setup the main interface layout"""
        # Configure root
        self.root.configure(bg="#f8f9fa")
        
        # Create main container
        main_container = ttk.Frame(self.root, padding="10")
        main_container.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_container.columnconfigure(1, weight=1)
        main_container.rowconfigure(2, weight=1)
        
        # Setup sections
        self.setup_control_panel(main_container)
        self.setup_status_panel(main_container)
        self.setup_data_display(main_container)
        self.setup_trades_display(main_container)
        
    def setup_menu_bar(self):
        """Setup application menu bar"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        # File menu
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Connect to IBKR", command=self.connect_ibkr)
        file_menu.add_command(label="Disconnect", command=self.disconnect_ibkr)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        
        # Trading menu
        trading_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Trading", menu=trading_menu)
        trading_menu.add_command(label="Start Streaming", command=self.start_streaming)
        trading_menu.add_command(label="Stop Streaming", command=self.stop_streaming)
        trading_menu.add_separator()
        trading_menu.add_command(label="Force Trade Mode", command=self.toggle_force_trade)
        
        # Tools menu
        tools_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Tools", menu=tools_menu)
        tools_menu.add_command(label="Backtest Strategy", command=self.run_backtest)
        tools_menu.add_command(label="Risk Summary", command=self.show_risk_summary)
        tools_menu.add_command(label="Performance Stats", command=self.show_performance_stats)
        
        # Help menu
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self.show_about)
        
    def setup_control_panel(self, parent):
        """Setup trading control panel"""
        control_frame = ttk.LabelFrame(parent, text="Trading Controls", padding="10")
        control_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # Connection controls
        conn_frame = ttk.Frame(control_frame)
        conn_frame.grid(row=0, column=0, columnspan=4, sticky=(tk.W, tk.E), pady=(0, 10))
        
        ttk.Button(conn_frame, text="Connect IBKR", command=self.connect_ibkr).grid(row=0, column=0, padx=(0, 5))
        ttk.Button(conn_frame, text="Disconnect", command=self.disconnect_ibkr).grid(row=0, column=1, padx=(0, 5))
        ttk.Label(conn_frame, text="Status:").grid(row=0, column=2, padx=(10, 5))
        ttk.Label(conn_frame, textvariable=self.connection_status, foreground="red").grid(row=0, column=3)
        
        # Trading parameters
        params_frame = ttk.Frame(control_frame)
        params_frame.grid(row=1, column=0, columnspan=4, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # Tickers input
        ttk.Label(params_frame, text="Tickers:").grid(row=0, column=0, sticky=tk.W, padx=(0, 5))
        ttk.Entry(params_frame, textvariable=self.tickers_var, width=30).grid(row=0, column=1, padx=(0, 10))
        
        # Exchange selection
        ttk.Label(params_frame, text="Exchange:").grid(row=0, column=2, sticky=tk.W, padx=(0, 5))
        exchange_combo = ttk.Combobox(params_frame, textvariable=self.exchange_var, 
                                     values=self.config.get_exchanges(), width=15)
        exchange_combo.grid(row=0, column=3, padx=(0, 10))
        
        # Chart interval
        ttk.Label(params_frame, text="Interval:").grid(row=1, column=0, sticky=tk.W, padx=(0, 5))
        interval_combo = ttk.Combobox(params_frame, textvariable=self.chart_interval_var,
                                     values=self.config.get_chart_intervals(), width=15)
        interval_combo.grid(row=1, column=1, padx=(0, 10))
        
        # Streaming controls
        stream_frame = ttk.Frame(control_frame)
        stream_frame.grid(row=2, column=0, columnspan=4, sticky=(tk.W, tk.E))
        
        ttk.Button(stream_frame, text="Start Streaming", command=self.start_streaming).grid(row=0, column=0, padx=(0, 5))
        ttk.Button(stream_frame, text="Stop Streaming", command=self.stop_streaming).grid(row=0, column=1, padx=(0, 5))
        ttk.Checkbutton(stream_frame, text="Force Trade Mode", variable=self.force_trade_var).grid(row=0, column=2, padx=(10, 5))
        ttk.Button(stream_frame, text="Run Backtest", command=self.run_backtest).grid(row=0, column=3, padx=(10, 0))
        
    def setup_status_panel(self, parent):
        """Setup status information panel"""
        status_frame = ttk.LabelFrame(parent, text="Account Status", padding="10")
        status_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # Status information
        ttk.Label(status_frame, text="Streaming:").grid(row=0, column=0, sticky=tk.W, padx=(0, 5))
        ttk.Label(status_frame, textvariable=self.streaming_status).grid(row=0, column=1, padx=(0, 20))
        
        ttk.Label(status_frame, text="Account Balance:").grid(row=0, column=2, sticky=tk.W, padx=(0, 5))
        ttk.Label(status_frame, textvariable=self.account_balance).grid(row=0, column=3, padx=(0, 20))
        
        # Performance metrics
        self.daily_pnl_var = tk.StringVar(value="$0.00")
        self.win_rate_var = tk.StringVar(value="0%")
        
        ttk.Label(status_frame, text="Daily P&L:").grid(row=1, column=0, sticky=tk.W, padx=(0, 5))
        ttk.Label(status_frame, textvariable=self.daily_pnl_var).grid(row=1, column=1, padx=(0, 20))
        
        ttk.Label(status_frame, text="Win Rate:").grid(row=1, column=2, sticky=tk.W, padx=(0, 5))
        ttk.Label(status_frame, textvariable=self.win_rate_var).grid(row=1, column=3)
        
    def setup_data_display(self, parent):
        """Setup market data display"""
        data_frame = ttk.LabelFrame(parent, text="Live Market Data", padding="5")
        data_frame.grid(row=2, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(0, 5))
        data_frame.columnconfigure(0, weight=1)
        data_frame.rowconfigure(0, weight=1)
        
        # Create treeview for market data
        columns = ("Symbol", "Price", "Change", "RSI", "BB%", "Stoch K", "Stoch D", "Volume", "Signal")
        self.market_tree = ttk.Treeview(data_frame, columns=columns, show="headings", height=12)
        
        # Configure columns
        for col in columns:
            self.market_tree.heading(col, text=col)
            self.market_tree.column(col, width=80, anchor=tk.CENTER)
            
        # Add scrollbar
        market_scrollbar = ttk.Scrollbar(data_frame, orient=tk.VERTICAL, command=self.market_tree.yview)
        self.market_tree.configure(yscrollcommand=market_scrollbar.set)
        
        self.market_tree.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        market_scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
    def setup_trades_display(self, parent):
        """Setup trades and positions display"""
        trades_frame = ttk.LabelFrame(parent, text="Open Positions & Trade History", padding="5")
        trades_frame.grid(row=2, column=1, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(5, 0))
        trades_frame.columnconfigure(0, weight=1)
        trades_frame.rowconfigure(0, weight=1)
        
        # Create notebook for different views
        trades_notebook = ttk.Notebook(trades_frame)
        trades_notebook.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Open positions tab
        positions_frame = ttk.Frame(trades_notebook)
        trades_notebook.add(positions_frame, text="Open Positions")
        
        pos_columns = ("Symbol", "Qty", "Entry Price", "Current Price", "P&L", "Stop Loss")
        self.positions_tree = ttk.Treeview(positions_frame, columns=pos_columns, show="headings", height=6)
        
        for col in pos_columns:
            self.positions_tree.heading(col, text=col)
            self.positions_tree.column(col, width=80, anchor=tk.CENTER)
            
        self.positions_tree.pack(fill=tk.BOTH, expand=True)
        
        # Trade history tab
        history_frame = ttk.Frame(trades_notebook)
        trades_notebook.add(history_frame, text="Trade History")
        
        hist_columns = ("Symbol", "Entry Time", "Exit Time", "Qty", "Entry Price", "Exit Price", "P&L")
        self.history_tree = ttk.Treeview(history_frame, columns=hist_columns, show="headings", height=6)
        
        for col in hist_columns:
            self.history_tree.heading(col, text=col)
            self.history_tree.column(col, width=80, anchor=tk.CENTER)
            
        self.history_tree.pack(fill=tk.BOTH, expand=True)
        
    def start_periodic_updates(self):
        """Start periodic GUI updates"""
        self.update_status_display()
        self.root.after(self.config.update_interval_ms, self.start_periodic_updates)
        
    def update_status_display(self):
        """Update status information"""
        try:
            # Update connection status
            if self.trading_engine.is_connected:
                self.connection_status.set("Connected")
            else:
                self.connection_status.set("Disconnected")
                
            # Update streaming status
            if self.trading_engine.is_streaming:
                self.streaming_status.set("Active")
            else:
                self.streaming_status.set("Stopped")
                
            # Update performance stats
            stats = self.trading_engine.get_performance_stats()
            self.daily_pnl_var.set(f"${stats.get('daily_pnl', 0):.2f}")
            self.win_rate_var.set(f"{stats.get('win_rate', 0):.1f}%")
            
        except Exception as e:
            self.logger.error(f"Status update error: {e}")
            
    def update_market_data(self, market_data: Dict):
        """Update market data display"""
        try:
            # Clear existing data
            for item in self.market_tree.get_children():
                self.market_tree.delete(item)
                
            # Add new data
            for symbol, data in market_data.items():
                try:
                    # Extract values with defaults
                    price = data.get('last', 0)
                    change = data.get('price_change', {}).get('percent_change', 0)
                    rsi = data.get('rsi', {}).get('value', 50)
                    bb_pos = data.get('bollinger', {}).get('position_percent', 50)
                    stoch_k = data.get('stochastic', {}).get('k_percent', 50)
                    stoch_d = data.get('stochastic', {}).get('d_percent', 50)
                    volume = data.get('volume_analysis', {}).get('current_volume', 0)
                    
                    # Determine signal
                    signals = data.get('signals', {})
                    if signals.get('buy_signal'):
                        signal = "BUY"
                    elif signals.get('sell_signal'):
                        signal = "SELL"
                    else:
                        signal = "HOLD"
                        
                    # Format values
                    values = (
                        symbol,
                        f"${price:.2f}",
                        f"{change:+.2f}%",
                        f"{rsi:.1f}",
                        f"{bb_pos:.1f}%",
                        f"{stoch_k:.1f}",
                        f"{stoch_d:.1f}",
                        f"{volume:,.0f}",
                        signal
                    )
                    
                    # Insert with color coding
                    item = self.market_tree.insert("", "end", values=values)
                    
                    # Color code based on change
                    if change > 0:
                        self.market_tree.set(item, "Change", f"+{change:.2f}%")
                    elif change < 0:
                        self.market_tree.set(item, "Change", f"{change:.2f}%")
                        
                except Exception as e:
                    self.logger.error(f"Error updating market data for {symbol}: {e}")
                    
        except Exception as e:
            self.logger.error(f"Market data update error: {e}")
            
    def update_trades_display(self, active_orders: Dict, trade_history: list):
        """Update trades display"""
        try:
            # Update open positions
            for item in self.positions_tree.get_children():
                self.positions_tree.delete(item)
                
            for symbol, position in active_orders.items():
                try:
                    qty = position.get('quantity', 0)
                    entry_price = position.get('actual_entry_price', position.get('entry_price', 0))
                    current_price = self.trading_engine.market_data.get(symbol, {}).get('last', 0)
                    stop_loss = position.get('stop_loss', 0)
                    
                    pnl = (current_price - entry_price) * qty if current_price > 0 else 0
                    
                    values = (
                        symbol,
                        qty,
                        f"${entry_price:.2f}",
                        f"${current_price:.2f}",
                        f"${pnl:.2f}",
                        f"${stop_loss:.2f}"
                    )
                    
                    self.positions_tree.insert("", "end", values=values)
                    
                except Exception as e:
                    self.logger.error(f"Error updating position for {symbol}: {e}")
                    
            # Update trade history (last 50 trades)
            for item in self.history_tree.get_children():
                self.history_tree.delete(item)
                
            for trade in trade_history[-50:]:  # Show last 50 trades
                try:
                    values = (
                        trade.get('symbol', ''),
                        trade.get('entry_time', datetime.now()).strftime('%H:%M:%S'),
                        trade.get('exit_time', datetime.now()).strftime('%H:%M:%S'),
                        trade.get('quantity', 0),
                        f"${trade.get('actual_entry_price', 0):.2f}",
                        f"${trade.get('actual_exit_price', 0):.2f}",
                        f"${trade.get('final_pnl', 0):.2f}"
                    )
                    
                    self.history_tree.insert("", "end", values=values)
                    
                except Exception as e:
                    self.logger.error(f"Error updating trade history: {e}")
                    
        except Exception as e:
            self.logger.error(f"Trades display update error: {e}")
            
    # Event handlers
    def connect_ibkr(self):
        """Connect to IBKR in async thread"""
        def connect_async():
            try:
                if self.trading_engine.event_loop:
                    future = asyncio.run_coroutine_threadsafe(
                        self.trading_engine.connect_ibkr(),
                        self.trading_engine.event_loop
                    )
                    success = future.result(timeout=10)
                    
                    if success:
                        self.root.after(0, lambda: messagebox.showinfo("Success", "Connected to IBKR"))
                    else:
                        self.root.after(0, lambda: messagebox.showerror("Error", "Failed to connect to IBKR"))
            except Exception as e:
                self.logger.error(f"Connection error: {e}")
                self.root.after(0, lambda: messagebox.showerror("Error", f"Connection failed: {e}"))
                
        threading.Thread(target=connect_async, daemon=True).start()
        
    def disconnect_ibkr(self):
        """Disconnect from IBKR"""
        self.trading_engine.disconnect()
        messagebox.showinfo("Info", "Disconnected from IBKR")
        
    def start_streaming(self):
        """Start market data streaming"""
        def start_async():
            try:
                tickers = self.tickers_var.get().strip()
                if not tickers:
                    self.root.after(0, lambda: messagebox.showerror("Error", "Please enter ticker symbols"))
                    return
                    
                if self.trading_engine.event_loop:
                    future = asyncio.run_coroutine_threadsafe(
                        self.trading_engine.start_streaming(tickers),
                        self.trading_engine.event_loop
                    )
                    success = future.result(timeout=10)
                    
                    if success:
                        self.is_streaming.set(True)
                        self.root.after(0, lambda: messagebox.showinfo("Success", "Streaming started"))
                    else:
                        self.root.after(0, lambda: messagebox.showerror("Error", "Failed to start streaming"))
            except Exception as e:
                self.logger.error(f"Streaming start error: {e}")
                self.root.after(0, lambda: messagebox.showerror("Error", f"Streaming failed: {e}"))
                
        threading.Thread(target=start_async, daemon=True).start()
        
    def stop_streaming(self):
        """Stop market data streaming"""
        self.trading_engine.stop_streaming()
        self.is_streaming.set(False)
        messagebox.showinfo("Info", "Streaming stopped")
        
    def toggle_force_trade(self):
        """Toggle force trade mode"""
        force_mode = self.force_trade_var.get()
        # This would be used by the trading engine to override some safety checks
        self.logger.info(f"Force trade mode: {'ON' if force_mode else 'OFF'}")
        
    def run_backtest(self):
        """Run backtest (placeholder)"""
        messagebox.showinfo("Backtest", "Backtesting functionality will be implemented here")
        
    def show_risk_summary(self):
        """Show risk management summary"""
        try:
            risk_summary = self.trading_engine.risk_manager.get_risk_summary()
            
            message = f"""Risk Management Summary:
            
Daily P&L: ${risk_summary.get('daily_pnl', 0):.2f}
Daily Loss Limit: ${risk_summary.get('daily_loss_limit', 0):.2f}
Remaining Limit: ${risk_summary.get('loss_limit_remaining', 0):.2f}

Active Trades: {len(self.trading_engine.active_orders)}
Max Open Trades: {risk_summary.get('max_open_trades', 0)}

Symbols in Cooldown: {', '.join(risk_summary.get('symbols_in_cooldown', []))}
Stop Loss Percentage: {risk_summary.get('hard_stop_loss_percent', 0):.1f}%"""
            
            messagebox.showinfo("Risk Summary", message)
            
        except Exception as e:
            self.logger.error(f"Risk summary error: {e}")
            messagebox.showerror("Error", f"Failed to get risk summary: {e}")
            
    def show_performance_stats(self):
        """Show performance statistics"""
        try:
            stats = self.trading_engine.get_performance_stats()
            
            message = f"""Performance Statistics:
            
Daily P&L: ${stats.get('daily_pnl', 0):.2f}
Total Trades: {stats.get('total_trades', 0)}
Winning Trades: {stats.get('winning_trades', 0)}
Win Rate: {stats.get('win_rate', 0):.1f}%
Active Positions: {stats.get('active_positions', 0)}"""
            
            messagebox.showinfo("Performance Stats", message)
            
        except Exception as e:
            self.logger.error(f"Performance stats error: {e}")
            messagebox.showerror("Error", f"Failed to get performance stats: {e}")
            
    def show_about(self):
        """Show about dialog"""
        about_text = """AutoTrade Plus v2.0
        
Interactive Brokers Trading Application
with Real-time Technical Analysis

Features:
• Live market data streaming
• Technical analysis (RSI, Bollinger Bands, Stochastic)
• Automated trading with risk management
• Real-time P&L tracking
• Position management

© 2025 AutoTrade Plus"""
        
        messagebox.showinfo("About AutoTrade Plus", about_text)
