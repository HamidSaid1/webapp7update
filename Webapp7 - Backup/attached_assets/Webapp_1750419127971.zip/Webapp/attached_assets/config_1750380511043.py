"""
Configuration management for the trading application
"""

import os
from dataclasses import dataclass
from typing import Dict, Any
import logging

@dataclass
class TradingConfig:
    """Configuration class for trading parameters"""
    
    # IBKR Connection Settings
    ibkr_host: str = "127.0.0.1"
    ibkr_port: int = 7497
    client_id: int = 2
    
    # Default Trading Parameters
    default_tickers: str = "AAPL,MSFT,GOOGL"
    default_exchange: str = "SMART"
    equity_per_trade: float = 1000.0
    max_open_trades: int = 3
    hard_stop_loss: float = 0.03  # 3%
    
    # Technical Analysis Parameters
    rsi_period: int = 14
    bb_period: int = 20
    bb_std_dev: float = 2.0
    stoch_k_period: int = 14
    stoch_d_period: int = 3
    
    # Data Collection Settings
    data_points: int = 50
    chart_interval: str = "5 mins"
    analysis_interval: int = 5  # seconds
    duration_str: str = "1 D"
    
    # Risk Management
    max_daily_loss: float = 5000.0
    position_size_percent: float = 0.02  # 2% of account
    cooldown_minutes: int = 30
    
    # GUI Settings
    update_interval_ms: int = 1000
    theme_color: str = "#007BFF"
    
    def __post_init__(self):
        """Load configuration from environment variables"""
        self.load_from_env()
        self.validate_config()
        
    def load_from_env(self):
        """Load configuration from environment variables"""
        # IBKR Settings
        self.ibkr_host = os.getenv("IBKR_HOST", self.ibkr_host)
        self.ibkr_port = int(os.getenv("IBKR_PORT", str(self.ibkr_port)))
        self.client_id = int(os.getenv("IBKR_CLIENT_ID", str(self.client_id)))
        
        # Trading Parameters
        self.equity_per_trade = float(os.getenv("EQUITY_PER_TRADE", str(self.equity_per_trade)))
        self.max_open_trades = int(os.getenv("MAX_OPEN_TRADES", str(self.max_open_trades)))
        self.hard_stop_loss = float(os.getenv("HARD_STOP_LOSS", str(self.hard_stop_loss)))
        
        # Risk Management
        self.max_daily_loss = float(os.getenv("MAX_DAILY_LOSS", str(self.max_daily_loss)))
        self.position_size_percent = float(os.getenv("POSITION_SIZE_PERCENT", str(self.position_size_percent)))
        
    def validate_config(self):
        """Validate configuration parameters"""
        logger = logging.getLogger(__name__)
        
        if self.equity_per_trade <= 0:
            raise ValueError("Equity per trade must be positive")
            
        if self.max_open_trades <= 0:
            raise ValueError("Max open trades must be positive")
            
        if not (0 < self.hard_stop_loss < 1):
            raise ValueError("Hard stop loss must be between 0 and 1")
            
        if self.rsi_period <= 0:
            raise ValueError("RSI period must be positive")
            
        logger.info("Configuration validated successfully")
        
    def get_chart_intervals(self) -> list:
        """Get available chart intervals"""
        return ["1 min", "3 mins", "5 mins", "10 mins", "15 mins", "30 mins", "1 hour"]
        
    def get_exchanges(self) -> list:
        """Get available exchanges"""
        return ["SMART", "NYSE", "NASDAQ", "AMEX", "ARCA"]
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary"""
        return {
            'ibkr_host': self.ibkr_host,
            'ibkr_port': self.ibkr_port,
            'client_id': self.client_id,
            'equity_per_trade': self.equity_per_trade,
            'max_open_trades': self.max_open_trades,
            'hard_stop_loss': self.hard_stop_loss,
            'rsi_period': self.rsi_period,
            'bb_period': self.bb_period,
            'stoch_k_period': self.stoch_k_period,
            'stoch_d_period': self.stoch_d_period
        }
        
    def update_from_dict(self, config_dict: Dict[str, Any]):
        """Update config from dictionary"""
        for key, value in config_dict.items():
            if hasattr(self, key):
                setattr(self, key, value)
        self.validate_config()
